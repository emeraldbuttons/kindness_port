ADVANCED PLATFORM ENGINE
by Noel Berry (www.noelberry.ca)

Flash Punk Library by Chevy Ray (read the FlashPunk Licence.txt for more info)
----------------------------------------------------------------

Title: ADVANCED PLATFORM ENGINE
Version: 0.85
Auhtor: Noel Berry
Flash Punk Version: 1.4
Description:
This platform engine uses the Flash Punk library (www.flashpunk.net) and demonstrates how to create more advanced platform game.

You are free to use this however you want, and do whatever you want with it (note, this applies to the Advanced Platform Engine code, located in the src folder, and NOT the flashpunk code, located in net/flashpunk. Please refer to the FlashPunk Licence.txt for more information on Flashpunk).

Have fun! :D

CHANGES (V0.8 to V0.85)
----------------------------------------------------------------
 - Added Double-Jumping
 - Added Wall-Jumping
 - Changed how max-speed works in the player so that wall jumping would work more efficiently
 - Added two new variables to the player, doublejump and walljumping, for doublejumping and walljumping respectively.
 - Updated to FlashPunk 1.4